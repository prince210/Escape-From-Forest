Chisel Mark
https://www.dafont.com/chisel-mark.font